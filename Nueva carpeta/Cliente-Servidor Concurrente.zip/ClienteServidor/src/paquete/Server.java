package paquete;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
 * Un servidor que acepta los solicitudes de clientes.
 * Cuando  se acepta una solicitud un nuevo usuario un
 * thread es instanciado para su manipulaci�n.
 */
public class Server {

	private JFrame frame = new JFrame("Servidor");  
	private JLabel label = new JLabel("MENSAJES",  SwingConstants.CENTER);
    private static JTextArea messageArea = new JTextArea(8, 60);
	
	/**
	 * Constructor del servidor, se contruye la GUI.    
	 */
    public Server() {
    	// Layout GUI
        messageArea.setEditable(false);
        frame.getContentPane().add(label, "North");
        frame.getContentPane().add(new JScrollPane(messageArea), "Center");        
    }
    
    /**
     * El servidor escucha en el puerto 9898.
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
    	Server server = new Server();
    	server.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	server.frame.pack();
    	server.frame.setVisible(true);
    	
    	System.out.println("The server is running.");
        int clientNumber = 0;
        ServerSocket listener = new ServerSocket(9898);
        try {
            while (true) {
                new ManejadorCliente(listener.accept(), clientNumber++).start();
            }
        } finally {
            listener.close();
        }
    }

    /**
     * Un thread privado para manejar los clientes.
     */
    private static class ManejadorCliente extends Thread {
        private Socket socket;
        private int clientNumber;

        public ManejadorCliente(Socket socket, int clientNumber) {
            this.socket = socket;
            this.clientNumber = clientNumber;
            log("New connection with client# " + clientNumber + " en " + socket);
        }

        /**
         * Envia mensajes de bienvenida y de confirmaci�n. 
         */
        public void run() {
            try {

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                // Enviar mensajes de bienvenida.
                out.println("Hola, tu eres el cliente # " + clientNumber + ".");
                out.println("Escribe \".\" y pulsa ENTER para salir\n");

                // Enviar confirmaci�n y actualizar JTextArea
                while (true) {
                    String input = in.readLine();
                    if (input == null || input.equals(".")) {
                        break;
                    }
                    messageArea.append("Cliente " + clientNumber + " dice: " + input+ "\n");                    
                    out.println("Mensaje enviado y recibido!");
                }
            } catch (IOException e) {
                log("Error handling client# " + clientNumber + ": " + e);
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    log("Couldn't close a socket, what's going on?");
                }
                log("Connection with client# " + clientNumber + " closed");
            }
        }

        /**
         * Registro del servidor
         */
        private void log(String message) {
            System.out.println(message);
        }
    }
}
